<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="description" content="cajas sorpresa, box, papaleria, retuladores, lapices, gomas, estuches, bonitos">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="images/icon.jpg">
    <title>Contacto</title>

    <!-- Hoja de estilo css principal -->
    <link rel="stylesheet" href="css/style.css">
    <!--Links de Boostrap-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="logicaJS.js"></script>
</head>

<body class="fondo">
    <!--Cabecera-->
    <div class="sticky-top">
        <header>
            <nav class="navbar navbar-expand-xl bg-dark navbar-dark">
                <div class="navbar-brand">
                    <a href="index.php">
                        <img id="gif" class="static" src="images/logoIndex.png" onmouseover="mostrarGif(this)" onmouseout="ocultarGif(this)">
                    </a>
                </div>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                        <span class="navbar-toggler-icon"></span>
                        </button>
                <div class="collapse navbar-collapse " id="collapsibleNavbar">

                    <ul class="nav navbar-nav">

                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Inicio</a>
                        </li>
                       
                        <li class="nav-item">
                            <a class="nav-link" href="productos.php">Productos</a>
                        </li>
                       <?php 
                       session_start();
                       
                       if (isset($_SESSION['username'])) {
                            if($_SESSION['username']=="admin"){
                                echo '
                            <li class="nav-item" id="btnEdicionP">
                            <a class="nav-link" href="tablaP.php">Edición de Productos</a>
                            </li>
                                 ';
                            }     
                         }
                       ?>
                        <li class="nav-item">
                            <a class="nav-link" href="envios.php">Envíos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contacto.php">Contacto</a>
                        </li>
                    </ul>

                    <ul  id = "btnLog" class="col-5 btn-group btn-group-justified d-inline-flex nav navbar-nav navbar-nav-rigth">
                        <?php
                       
                       
                       if (isset($_SESSION['username'])) {
                        $user = $_SESSION['username'];
                        echo '
                        <li class="col-sm-6 d-xs-inline nav-item">
                            <a class="btn btn-outline-danger navbar-btn nav-link" href="logicaSesiones/salir.php"><span class="fa fa-user-plus "aria-hidden="true" ></span> Cerrar Sesión</a>
                        </li>

                        <li class="col-sm-6  nav-item">
                            <a class="btn btn-outline-danger navbar-btn nav-link" href="#"><span class="fa fa-sign-in" aria-hidden="true"></span> Hola '.$user.'!</a>
                        </li>';
                        }else{
                        echo '
                            <li class="col-sm-6 d-xs-inline nav-item">
                                 <a class="btn btn-outline-danger navbar-btn nav-link" href="registro.php"><span class="fa fa-user-plus "aria-hidden="true" ></span> Registrarse</a>
                             </li>

                             <li class="col-sm-6  nav-item">
                                 <a class="btn btn-outline-danger navbar-btn nav-link" href="login.php"><span class="fa fa-sign-in" aria-hidden="true"></span> Iniciar Sesión</a>
                             </li>';
                      }
                       
                       ?>
                    
                       
                    </ul>

                </div>
            </nav>

        </header>
    </div>
    <!--Cuerpo-->



    <div class="container">

        <div class="row jumbotron justify-content-center fondoJumbo">

            <h1>Contacto</h1>
            </img>
        </div>

        <div class="container">
            <div class="row">


                <div class="col-lg-6 col-md-6 d-none d-md-block">
                    <div class="container">
                        <h1 id="bienbenidaUsuario"></h1>
                        <img class="img-thumbnail ml-3 w-75" src="images/Dato de contacto.png" alt="640283666">
                    </div>
                </div>






                <div class="col-lg-6 col-md-6 col-12">
                    <div class="well well-sm">
                        <form class="form-horizontal" method="post">
                            <div class="form-group row">
                                <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-user bigicon"></i></span>
                                <div class="col-md-8">
                                    <div class="input-group">
                                        <input id="nombre" name="nombre" type="text" placeholder="Nombre" class="form-control">
                                    </div>
                                </div>
                            </div>

                            <div class="form-group row">
                                <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-user bigicon"></i></span>
                                <div class="col-md-8">
                                    <div class="input-group">
                                        <input id="apellido" name="apellido" type="text" placeholder="Apellidos" class="form-control">
                                    </div>
                                </div>
                            </div>

                            <div class="form-group row">
                                <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-envelope-o bigicon"></i></span>
                                <div class="col-md-8">
                                    <div class="input-group">
                                        <input id="mail" name="mail" type="text" placeholder="Dirección de correo electrónico" class="form-control">
                                    </div>
                                </div>
                            </div>


                            <div class="form-group row">
                                <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-phone-square bigicon"></i></span>
                                <div class="col-md-8">
                                    <div class="input-group">
                                        <input id="telefono" name="telefono" type="text" placeholder="Teléfono" class="form-control">
                                    </div>
                                </div>
                            </div>


                            <div class="form-group row">
                                <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-pencil-square-o bigicon"></i></span>
                                <div class="col-md-8">
                                    <textarea class="form-control" id="mensaje" name="mensaje" placeholder="Mensaje" rows="7"></textarea>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="offset-4 col-8">
                                    <button name="submit" type="submit" class="btn btn-primary">Enviar</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>

</body>

</html>