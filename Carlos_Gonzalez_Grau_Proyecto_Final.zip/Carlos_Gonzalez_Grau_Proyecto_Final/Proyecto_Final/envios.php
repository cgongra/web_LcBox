<!DOCTYPE html>
<html lang="es">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="description" content="cajas sorpresa, box, papaleria, retuladores, lapices, gomas, estuches, bonitos">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="images/icon.jpg">
    <script src="logicaJS.js"></script>
    <title>LCBox Envios</title>

    <!-- Hoja de estilo css principal -->
    <link rel="stylesheet" href="css/style.css">
    <!--Links de Boostrap-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body class="fondo">
      <!--Cabecera-->
      <div class="sticky-top">
        <header>
            <nav class="navbar navbar-expand-xl bg-dark navbar-dark">
                <div class="navbar-brand">
                    <a href="index.php">
                        <img id="gif" class="static" src="images/logoIndex.png" onmouseover="mostrarGif(this)" onmouseout="ocultarGif(this)">
                    </a>
                </div>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                        <span class="navbar-toggler-icon"></span>
                        </button>
                <div class="collapse navbar-collapse " id="collapsibleNavbar">

                    <ul class="nav navbar-nav">

                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Inicio</a>
                        </li>
                       
                        <li class="nav-item">
                            <a class="nav-link" href="productos.php">Productos</a>
                        </li>
                       <?php 
                       session_start();
                       
                       if (isset($_SESSION['username'])) {
                            if($_SESSION['username']=="admin"){
                                echo '
                            <li class="nav-item" id="btnEdicionP">
                            <a class="nav-link" href="tablaP.php">Edición de Productos</a>
                            </li>
                                 ';
                            }     
                         }
                       ?>
                        <li class="nav-item">
                            <a class="nav-link" href="envios.php">Envíos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contacto.php">Contacto</a>
                        </li>
                    </ul>

                    <ul  id = "btnLog" class="col-5 btn-group btn-group-justified d-inline-flex nav navbar-nav navbar-nav-rigth">
                        <?php
                       
                       
                       if (isset($_SESSION['username'])) {
                        $user = $_SESSION['username'];
                        echo '
                        <li class="col-sm-6 d-xs-inline nav-item">
                            <a class="btn btn-outline-danger navbar-btn nav-link" href="logicaSesiones/salir.php"><span class="fa fa-user-plus "aria-hidden="true" ></span> Cerrar Sesión</a>
                        </li>

                        <li class="col-sm-6  nav-item">
                            <a class="btn btn-outline-danger navbar-btn nav-link" href="#"><span class="fa fa-sign-in" aria-hidden="true"></span> Hola '.$user.'!</a>
                        </li>';
                        }else{
                        echo '
                            <li class="col-sm-6 d-xs-inline nav-item">
                                 <a class="btn btn-outline-danger navbar-btn nav-link" href="registro.php"><span class="fa fa-user-plus "aria-hidden="true" ></span> Registrarse</a>
                             </li>

                             <li class="col-sm-6  nav-item">
                                 <a class="btn btn-outline-danger navbar-btn nav-link" href="login.php"><span class="fa fa-sign-in" aria-hidden="true"></span> Iniciar Sesión</a>
                             </li>';
                      }
                       
                       ?>
                    
                       
                    </ul>

                </div>
            </nav>

        </header>
    </div>
    <!--Cuerpo-->
    <div class="container">
        <div class="row d-none d-lg-block ">
            <div class="carousel slide" data-ride="carousel">

                <!-- Indicators -->
                <ul class="carousel-indicators">
                    <li data-target="#demo" data-slide-to="0"></li>
                    <li data-target="#demo" data-slide-to="1" class="active"></li>
                    <li data-target="#demo" data-slide-to="2"></li>
                </ul>

                <!-- The slideshow -->
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="images/EnvioGratis.png" alt="Los Angeles" width="1100" height="500">
                    </div>
                    <div class="carousel-item">
                        <img src="images/recibeC.webp" alt="Chicago" width="1100" height="500">
                    </div>
                    <div class="carousel-item">
                        <img src="images/caja.png" alt="New York" width="1100" height="500">
                    </div>
                </div>

                <!-- Left and right controls -->
                <a class="carousel-control-prev" href="#demo" data-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                </a>
                <a class="carousel-control-next" href="#demo" data-slide="next">
                    <span class="carousel-control-next-icon"></span>
                </a>
            </div>
        </div>
        <br>
        <div class="row justify-content-center">

            <div class="col-5">
                <h4>Puedes utilizar los siguientes puntos de recogida</h4>

            </div>
            <div class="col-auto"></div>
            <div class="col-5">
                <h4>Envío a domicilio</h4>
                <p>¡Hacemos envíos a domicilio a toda la península!</p>

            </div>
        </div>
        <br>
        <div class="row justify-content-center">
            <div class="map-responsive d-none d-md-block">
                <iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d50726.644025141555!2d-5.979894538252307!3d37.38001088728942!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1samazon!5e0!3m2!1ses!2ses!4v1638898016245!5m2!1ses!2ses" width="600" height="450"
                    style="border:0;" allowfullscreen="" loading="lazy"></iframe>
            </div>
            <div class="d-md-none d-block">
                <img src="images/envio.jpg">
                <hr>
                <p>A partir de 50€</p>
                <img src="images/EnvioGratis.png">
            </div>
        </div>
    </div>



</body>
<div class="cabecera fondo">
    <div class="d-flex flex-row justify-content-start justify-content-md-center">
        <div class="row input-group d-inline">
            <a class="cabeceraContacto" href="mailto:lcboxxshop@gmail.com">
                <span class="space"> <i class="fa fa-envelope-o" aria-hidden="true"></i></span> lcboxxshop@gmail.com
            </a>

            <a class="cabeceraContacto" href="tel:+34-640283666">
                <span class="space"> <i class="fa fa-phone" aria-hidden="true"></i></span>640283666
            </a>
        </div>
    </div>
</html>