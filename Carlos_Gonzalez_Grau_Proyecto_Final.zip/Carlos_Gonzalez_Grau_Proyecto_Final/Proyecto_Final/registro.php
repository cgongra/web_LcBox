<!DOCTYPE html>
<html lang="es">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="description" content="cajas sorpresa, box, papaleria, retuladores, lapices, gomas, estuches, bonitos">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="images/icon.jpg">
    <title>LCBox</title>

    <!-- Hoja de estilo css principal -->
    <link rel="stylesheet" href="css/style.css">
    <!--Links de Boostrap-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="logicaJS.js"></script>
</head>

<body class="fondo">

     <!--Cabecera-->
     <div class="sticky-top">
        <header>
            <nav class="navbar navbar-expand-xl bg-dark navbar-dark">
                <div class="navbar-brand">
                    <a href="index.php">
                        <img id="gif" class="static" src="images/logoIndex.png" onmouseover="mostrarGif(this)" onmouseout="ocultarGif(this)">
                    </a>
                </div>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                        <span class="navbar-toggler-icon"></span>
                        </button>
                <div class="collapse navbar-collapse " id="collapsibleNavbar">

                    <ul class="nav navbar-nav">

                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Inicio</a>
                        </li>
                       
                        <li class="nav-item">
                            <a class="nav-link" href="productos.php">Productos</a>
                        </li>
                       <?php 
                       session_start();
                       
                       if (isset($_SESSION['username'])) {
                            if($_SESSION['username']=="admin"){
                                echo '
                            <li class="nav-item" id="btnEdicionP">
                            <a class="nav-link" href="tablaP.php">Edición de Productos</a>
                            </li>
                                 ';
                            }     
                         }
                       ?>
                        <li class="nav-item">
                            <a class="nav-link" href="envios.php">Envíos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contacto.php">Contacto</a>
                        </li>
                    </ul>

                    <ul  id = "btnLog" class="col-5 btn-group btn-group-justified d-inline-flex nav navbar-nav navbar-nav-rigth">
                        <?php
                       
                       
                       if (isset($_SESSION['username'])) {
                        $user = $_SESSION['username'];
                        echo '
                        <li class="col-sm-6 d-xs-inline nav-item">
                            <a class="btn btn-outline-danger navbar-btn nav-link" href="logicaSesiones/salir.php"><span class="fa fa-user-plus "aria-hidden="true" ></span> Cerrar Sesión</a>
                        </li>

                        <li class="col-sm-6  nav-item">
                            <a class="btn btn-outline-danger navbar-btn nav-link" href="#"><span class="fa fa-sign-in" aria-hidden="true"></span> Hola '.$user.'!</a>
                        </li>';
                        }else{
                        echo '
                            <li class="col-sm-6 d-xs-inline nav-item">
                                 <a class="btn btn-outline-danger navbar-btn nav-link" href="registro.php"><span class="fa fa-user-plus "aria-hidden="true" ></span> Registrarse</a>
                             </li>

                             <li class="col-sm-6  nav-item">
                                 <a class="btn btn-outline-danger navbar-btn nav-link" href="login.php"><span class="fa fa-sign-in" aria-hidden="true"></span> Iniciar Sesión</a>
                             </li>';
                      }
                       
                       ?>
                    
                       
                    </ul>

                </div>
            </nav>

        </header>
    </div>
    <!--Cuerpo-->
    <div class="container">
        <div class="row justify-content-center ">
            <div class="col-12 ">
            <?php 
                    require_once "logicaSesiones/conexion.php";
                    require_once "logicaSesiones/ConsultasContoller.php";
                   // $nombre,$apellidos,$email, $telefono, $direccion, $usuario, $clave
            if(isset($_POST['nombre'])){                   
                    $nombre = $_POST['nombre'];
                    $apellidos = $_POST['apellidos'];
                    $email = $_POST['email'];
                    $telefono = $_POST['telefono'];
                    $direccion = $_POST['direccion'];
                    $usuario = $_POST['usuario'];
                    $clave = $_POST['clave'];
                    $sentencia = new consultas();
                if(isset($_POST['telefono'])){
                    $resultado= $sentencia->insertarUsuario($nombre,$apellidos,$email, $telefono, $direccion, $usuario, $clave);

                    switch($resultado){
                        case "repetido":
                            echo '
                            <div class="row mt-2">
                            <div class="col-md-8 offset-md-2">
                                <div role="alert" class="alert alert-danger alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                                    <h4 class="alert-heading">El usuario ya se encuentra en nuestra base de datos</h4>
                                 </div>
                            </div>
                        </div>
                            ';
                        break;

                        case "success":
                            echo '
                            <div class="row mt-2">
                            <div class="col-md-5 offset-md-3">
                                <div role="alert" class="alert alert-success alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                                    <h4 class="alert-heading">¡Registrado correctamente!</h4>
                                 </div>
                            </div>
                        </div>
                            ';
                        break;
                        
                        case "error":
                            echo '
                            <div class="row mt-2">
                            <div class="col-md-5 offset-md-3">
                                <div role="alert" class="alert alert-danger alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                                    <h4 class="alert-heading">¡Error! No se ha podido registrar el usuario</h4>
                                 </div>
                            </div>
                        </div>
                            ';

                        break;

                    }
                }
            }
            ?>
            <div class="jumbotron bg-dark img-thumbnail jumbo mt-2 " style="opacity: 0.94;">
                <form id="formReg" action="" method="POST">
                <div class="form-group">
                    <h3 style="text-decoration: aqua; color: pink;">Formulario de registro</h3>
                    <br>
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <div class="input-group-text">
                        <i class="fa fa-address-card"></i>
                        </div>
                    </div> 
                    <input id="nombre" name="nombre" placeholder="Nombre" type="text" required="required" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <div class="input-group-text">
                        <i class="fa fa-address-book"></i>
                        </div>
                    </div> 
                    <input id="apellidos" name="apellidos" placeholder="Apellidos" type="text" required="required" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <div class="input-group-text">
                        <i class="fa fa-envelope"></i>
                        </div>
                    </div> 
                    <input id="email" name="email" placeholder="Correo electrónico" type="email" required="required" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label></label> 
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <div class="input-group-text">
                        <i class="fa fa-phone"></i>
                        </div>
                    </div> 
                    <input id="telefono" name="telefono" placeholder="Teléfono" type="text" required="required" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <div class="input-group-text">
                        <i class="fa fa-map"></i>
                        </div>
                    </div> 
                    <input id="direccion" name="direccion" placeholder="Dirección" type="text" required="required" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <div class="input-group-text">
                        <i class="fa fa-user"></i>
                        </div>
                    </div> 
                    <input id="usuario" name="usuario" placeholder="Usuario" type="text" required="required" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <div class="input-group-text">
                        <i class="fa fa-500px"></i>
                        </div>
                    </div> 
                    <input id="clave" name="clave" placeholder="Contraseña" type="password" required="required" class="form-control">
                    </div>
                    <small id="claveHelp" class="form-text text-muted">Recuerda, no compartas tu contraseña con nadie.</small>
                </div> 
                <hr>
                <div class="form-group ">
                    <button name="submit" type="submit" class="btn btn-outline-danger col-lg-4" style="color:#c2c2c2;"> Registrarse <span class="fa fa-paper-plane float-rigth" aria-hidden="true"></span></button>
                </div>
                </form>
            </div>
            </div>
        </div>
    </div>

</body>
<div class="cabecera fondo">
    <div class="d-flex flex-row justify-content-start justify-content-md-center">
        <div class="row input-group d-inline">
            <a class="cabeceraContacto" href="mailto:lcboxxshop@gmail.com">
                <span class="space"> <i class="fa fa-envelope-o" aria-hidden="true"></i></span> lcboxxshop@gmail.com
            </a>

            <a class="cabeceraContacto" href="tel:+34-640283666">
                <span class="space"> <i class="fa fa-phone" aria-hidden="true"></i></span>640283666
            </a>
        </div>
    </div>
</div>
</html>