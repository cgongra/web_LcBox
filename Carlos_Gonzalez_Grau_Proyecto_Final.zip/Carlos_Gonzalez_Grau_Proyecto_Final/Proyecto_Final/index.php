<!DOCTYPE html>
<html lang="es">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="description" content="cajas sorpresa, box, papaleria, retuladores, lapices, gomas, estuches, bonitos">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="images/icon.jpg">
    <title>LCBox</title>

    <!-- Hoja de estilo css principal -->
    <link rel="stylesheet" href="css/style.css">
    <!--Links de Boostrap-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="logicaJS.js"></script>
</head>

<body class="fondo">
  <!--Cabecera-->
  <div class="sticky-top">
        <header>
            <nav class="navbar navbar-expand-xl bg-dark navbar-dark">
                <div class="navbar-brand">
                    <a href="index.php">
                        <img id="gif" class="static" src="images/logoIndex.png" onmouseover="mostrarGif(this)" onmouseout="ocultarGif(this)">
                    </a>
                </div>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                        <span class="navbar-toggler-icon"></span>
                        </button>
                <div class="collapse navbar-collapse " id="collapsibleNavbar">

                    <ul class="nav navbar-nav">

                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Inicio</a>
                        </li>
                       
                        <li class="nav-item">
                            <a class="nav-link" href="productos.php">Productos</a>
                        </li>
                       <?php 
                       session_start();
                       
                       if (isset($_SESSION['username'])) {
                            if($_SESSION['username']=="admin"){
                                echo '
                            <li class="nav-item" id="btnEdicionP">
                            <a class="nav-link" href="tablaP.php">Edición de Productos</a>
                            </li>
                                 ';
                            }     
                         }
                       ?>
                        <li class="nav-item">
                            <a class="nav-link" href="envios.php">Envíos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contacto.php">Contacto</a>
                        </li>
                    </ul>

                    <ul  id = "btnLog" class="col-5 btn-group btn-group-justified d-inline-flex nav navbar-nav navbar-nav-rigth">
                        <?php
                       
                       
                       if (isset($_SESSION['username'])) {
                        $user = $_SESSION['username'];
                        echo '
                        <li class="col-sm-6 d-xs-inline nav-item">
                            <a class="btn btn-outline-danger navbar-btn nav-link" href="logicaSesiones/salir.php"><span class="fa fa-user-plus "aria-hidden="true" ></span> Cerrar Sesión</a>
                        </li>

                        <li class="col-sm-6  nav-item">
                            <a class="btn btn-outline-danger navbar-btn nav-link" href="#"><span class="fa fa-sign-in" aria-hidden="true"></span> Hola '.$user.'!</a>
                        </li>';
                        }else{
                        echo '
                            <li class="col-sm-6 d-xs-inline nav-item">
                                 <a class="btn btn-outline-danger navbar-btn nav-link" href="registro.php"><span class="fa fa-user-plus "aria-hidden="true" ></span> Registrarse</a>
                             </li>

                             <li class="col-sm-6  nav-item">
                                 <a class="btn btn-outline-danger navbar-btn nav-link" href="login.php"><span class="fa fa-sign-in" aria-hidden="true"></span> Iniciar Sesión</a>
                             </li>';
                      }
                       
                       ?>
                    
                       
                    </ul>

                </div>
            </nav>

        </header>
    </div>
    <!--Cuerpo-->


    <div class="jumbotron fondo">
        <img src="images/land.jpg" class="img-thumbnail jumbo mx-auto d-block w-75 mb-4"> 
        <?php
         if (isset($_SESSION['username'])) {
            $user = $_SESSION['username']; 
            echo "<div  class='saludo mt-2 d-flex'><h3>Bienvenido ".$user."</h3></div>";  
        }
        ?>
        <div class="container">
            <div class="row " id="landing-space">
                <div class="card-group">
                    <div class="col-md-12 col-lg-4 mt-2 ">
                        <div class="card p-3">
                        <?php 
                        require_once "logicaSesiones/conexion.php";
                        require_once "logicaSesiones/ConsultasContoller.php";
    
                        if(isset($_COOKIE["id"]) && $_COOKIE["id"] != "undefined") {           
                        $id = $_COOKIE["id"]; 
                        $sentencia = new consultas();
                        $mostrarDatos= $sentencia->obtenerProducto($id);
                        
                        foreach($mostrarDatos as $res){
                        
                           
                            $id = $res["idProducto"];
                            echo " 
                            
                            <div class='card-header'>";
                            if (isset($_SESSION['username'])) {
                                $user = $_SESSION['username']; 
                                echo "<h3>Para ti ".$user."</h3>";  
                            }
                            echo "<h3>El ultimo producto que te ha interesado ha sido</h3><br>
                                <img class='card-img-top' src=".$res["imagen"]." alt='No se pudo cargar la imagen' style='width:100%'>
                                    
                                    <div class='card-body'>
                                        <h4 class='card-title'>".$res["nombre"]."</h4>
                                        <p class='card-text'>".$res["precio"]." €</p>
                                    </div>
                                    
                                    <div class='card-footer '>
                                        <a href='productos.php' class='btn btn-primary stretched-link w-100 ' onclick='setCookies($id);'>Añadir al Carrito<i class='fa fa-shopping-cart ml-1'></i></a>
                                    </div>
                            </div>      
                                        
                            ";
                        }
                        }else{
                            echo '
                        <div class="card-header">
                                <p class="aligned-center"><i class="fa fa-user fa-3x circle-background"></i></p>
                                <h3>Registrate para no perderte ni una!</h3><br>
                                <p class="text-primary">Registrate ahora y obten un 10 % de descuento de bienvenida para tu primer mes</p>
                                <p><a href="productos.php" class="btn btn-info" title="Post an Ad"><i class="fa fa-plus fa-2x"></i></a></p>
                        </div>
                        
                        '; 
                        }
                    
                        ?>
                        </div>

                    </div>
                    <div class="col-lg-4 col-md-6 mt-2 h-100">
                        <div class="card p-2">
                            <div class="card-header">
                                <p class="aligned-center"><i class="fa fa-plane fa-3x circle-background"></i></p>
                                <h3>Envío gratuito el primer mes!</h3><br>
                                <p class="text-primary">Ningún mes es igual que el anterior así que no dejes escapar ni una LapiBox!</p><br>
                                <p><a href="envios.php" class="btn btn-info" title="View All Ads"><i class="fa fa-paper-plane-o fa-2x" aria-hidden="true"></i></a></p>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mt-2 h-100">
                        <div></div>
                        <div class="card p-3">
                            <div class="card-header">
                                <p class="aligned-center"><i class="fa fa-edit fa-3x circle-background"></i></p>
                                <h3>Échale un ojo al catálogo</h3><br>
                                <p class="text-primary">Tenemos LapiBox de todo tipo, además contamos con ediciones especiales de temáticas concretas</p>
                                <p><a href="productos.php" class="btn btn-info" title="Productos" href="productos.html"><i class="fa fa-angle-double-right fa-2x"></i></a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<div class="cabecera fondo">
    <div class="d-flex flex-row justify-content-start justify-content-md-center">
        <div class="row input-group d-inline">
            <a class="cabeceraContacto" href="mailto:lcboxxshop@gmail.com">
                <span class="space"> <i class="fa fa-envelope-o" aria-hidden="true"></i></span> lcboxxshop@gmail.com
            </a>

            <a class="cabeceraContacto" href="tel:+34-640283666">
                <span class="space"> <i class="fa fa-phone" aria-hidden="true"></i></span>640283666
            </a>
        </div>
    </div>
</div>
</body>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="JavaScript/funciones.js"></script>


</html>