<!DOCTYPE html>
<html lang="es">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="description" content="cajas sorpresa, box, papaleria, retuladores, lapices, gomas, estuches, bonitos">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LCBox</title>

    <!-- Hoja de estilo css principal -->
    <link rel="stylesheet" href="css/style.css">
    <!--Links de Boostrap-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="logicaJS.js"></script>


</head>

<body class="fondo">
  <!--Cabecera-->
  <div class="sticky-top">
        <header>
            <nav class="navbar navbar-expand-xl bg-dark navbar-dark">
                <div class="navbar-brand">
                    <a href="index.php">
                        <img id="gif" class="static" src="images/logoIndex.png" onmouseover="mostrarGif(this)" onmouseout="ocultarGif(this)">
                    </a>
                </div>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                        <span class="navbar-toggler-icon"></span>
                        </button>
                <div class="collapse navbar-collapse " id="collapsibleNavbar">

                    <ul class="nav navbar-nav">

                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Inicio</a>
                        </li>
                       
                        <li class="nav-item">
                            <a class="nav-link" href="productos.php">Productos</a>
                        </li>
                       <?php 
                       session_start();
                       
                       if (isset($_SESSION['username'])) {
                            if($_SESSION['username']=="admin"){
                                echo '
                            <li class="nav-item" id="btnEdicionP">
                            <a class="nav-link" href="tablaP.php">Edición de Productos</a>
                            </li>
                                 ';
                            }     
                         }
                       ?>
                        <li class="nav-item">
                            <a class="nav-link" href="envios.php">Envíos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contacto.php">Contacto</a>
                        </li>
                    </ul>

                    <ul  id = "btnLog" class="col-5 btn-group btn-group-justified d-inline-flex nav navbar-nav navbar-nav-rigth">
                        <?php
                       
                       
                       if (isset($_SESSION['username'])) {
                        $user = $_SESSION['username'];
                        echo '
                        <li class="col-sm-6 d-xs-inline nav-item">
                            <a class="btn btn-outline-danger navbar-btn nav-link" href="logicaSesiones/salir.php"><span class="fa fa-user-plus "aria-hidden="true" ></span> Cerrar Sesión</a>
                        </li>

                        <li class="col-sm-6  nav-item">
                            <a class="btn btn-outline-danger navbar-btn nav-link" href="#"><span class="fa fa-sign-in" aria-hidden="true"></span> Hola '.$user.'!</a>
                        </li>';
                        }else{
                        echo '
                            <li class="col-sm-6 d-xs-inline nav-item">
                                 <a class="btn btn-outline-danger navbar-btn nav-link" href="registro.php"><span class="fa fa-user-plus "aria-hidden="true" ></span> Registrarse</a>
                             </li>

                             <li class="col-sm-6  nav-item">
                                 <a class="btn btn-outline-danger navbar-btn nav-link" href="login.php"><span class="fa fa-sign-in" aria-hidden="true"></span> Iniciar Sesión</a>
                             </li>';
                      }
                       
                       ?>
                    
                       
                    </ul>

                </div>
            </nav>

        </header>
    </div>
    <!--Cuerpo-->
    <div class="container">

        <div class="row justify-content-center">
            <h1 class="mt-4">Productos Destacados</h1>
        </div>
        <div class="row">
            <div class="card-deck align-content-center" id="cardProducto">
                <?php 
                    require_once "logicaSesiones/conexion.php";
                    require_once "logicaSesiones/ConsultasContoller.php";

                    $sentencia = new consultas();
                    $mostrarDatos= $sentencia->selectProducto();
                    
                    foreach($mostrarDatos as $res){
                        $id = $res["idProducto"];
                        echo " 
                        <div class='col-12 col-md-6 col-lg-4 mt-3'>
                            <div class='card' style='width:300px'>
                                
                                <img class='card-img-top' src=".$res["imagen"]." alt='No se pudo cargar la imagen' style='width:100%'>
                                
                                <div class='card-body'>
                                    <h4 class='card-title'>".$res["nombre"]."</h4>
                                    <p class='card-text'>".$res["precio"]." €</p>
                                </div>
                                
                                <div class='card-footer '>
                                    <a href='#' class='btn btn-primary stretched-link w-100 ' onclick='setCookies($id);'>Añadir al Carrito<i class='fa fa-shopping-cart ml-1'></i></a>
                                </div>
                            </div>      
                        </div>                     
                        ";
                    }


                ?>                
            </div>
            <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
            <script src="JavaScript/funciones.js"></script>
        </div>    
    </div>









</body>
<div class="cabecera fondo mt-2">
    <div class="d-flex flex-row justify-content-start justify-content-md-center">
        <div class="row input-group d-inline">
            <a class="cabeceraContacto" href="mailto:lcboxxshop@gmail.com">
                <span class="space"> <i class="fa fa-envelope-o" aria-hidden="true"></i></span> lcboxxshop@gmail.com
            </a>

            <a class="cabeceraContacto" href="tel:+34-640283666">
                <span class="space"> <i class="fa fa-phone" aria-hidden="true"></i></span>640283666
            </a>
        </div>
    </div>
</html>