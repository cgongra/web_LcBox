<?php
    class consultas extends dbconexion{
       
        public function selectProducto(){
            $sqlp = dbconexion::conexion()->prepare(
                "SELECT * FROM producto");
            $sqlp->execute();
            return $array =$sqlp->fetchAll(PDO::FETCH_ASSOC);
        
        }

        public function insertarProducto($nombre,$precio,$img){
            $sql = dbconexion::conexion()->prepare("INSERT INTO producto(nombre, precio, imagen) VALUES ('$nombre','$precio','$img')");
            
            if($sql->execute()){
                $result= (new consultas) -> selectProducto();
                return $result;
            }
       
        }

        public function obtenerProducto($id){
            $sql= dbconexion::conexion()->prepare("SELECT * FROM producto WHERE idProducto ='".$id."' ");
            $sql->execute();
            // Si se ejecuta bien retotno el array con los datos del producto seleccionado, si no mando que algo ha ido mal
            if($sql->execute()){
                return $array = $sql->fetchAll(PDO::FETCH_ASSOC);
            }else{
                return "error";
            }
        }

        public function actualizar_producto($id, $nombre, $precio, $img){
            $sql =  dbconexion::conexion()->prepare("UPDATE producto SET nombre='".$nombre."',precio='".$precio."', imagen='".$img."' WHERE idProducto='".$id."' ");
            $sql->execute();
            if($sql->rowCount() > 0){
                $result= (new consultas) -> selectProducto();
                return $result;
            }else{
                return "error";
            }
        }

        public function eliminar_producto($id){
            $sql =  dbconexion::conexion()->prepare("DELETE FROM producto WHERE idProducto='".$id."' ");
            $sql->execute();
            if($sql->rowCount() > 0){
                $result= (new consultas) -> selectProducto();
                return $result;
            }else{
                return "error";
            }
        }

        public function insertarUsuario($nombre,$apellidos,$email, $telefono, $direccion, $usuario, $clave){
            //Consulta de comprobación
            $sqlp = dbconexion::conexion()->prepare("SELECT * FROM cuentas WHERE usuario= '".$usuario."';");
            //Comprobamos si hay algun usuario con ese nombre ya registrado
            $sqlp->execute();
            
            if($sqlp->rowCount() > 0){
                return "repetido";
            }else{
                //Consulta de inserción
                $sql = dbconexion::conexion()->prepare("INSERT INTO cuentas(usuario, clave, nombre, apellidos, telefono, direccion, email) VALUES ('".$usuario."','".$clave."','".$nombre."','".$apellidos."','".$telefono."','".$direccion."','".$email."')");
                //Si no hay un usuario con ese nombre se ejecuta la consulta
                
                //Compruebo que se haya podidoejecutar correctamente y si es así devuelvo un mensaje de éxito
                if($sql->execute()){
                    return "success";
                }else{
                    //En caso contrario devuelvo un mensaje de error
                    return "error";
                }
            }
        }
        
    }


?>