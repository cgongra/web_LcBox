<?php
 require_once '../logicaSesiones/conexion.php';

session_start();
$usuario = $_POST['usuario'];
$pasword = $_POST['pasword'];

$sql = (new dbconexion) -> conexion()-> prepare("SELECT tipo as tipo  from cuentas where  usuario = '$usuario' and clave = '$pasword'");
$sql->execute();
$array =$sql->fetchAll(PDO::FETCH_ASSOC);
if($sql->rowCount() > 0){

  $_SESSION['username'] = $usuario;
  $_SESSION['tipo'] = $array['tipo'];
  header("location: ../index.php");
  echo json_encode ($array);
} else {
  $resultado = "error";
  echo json_encode($resultado);
  header("location: ../login.html");
  

}



?>