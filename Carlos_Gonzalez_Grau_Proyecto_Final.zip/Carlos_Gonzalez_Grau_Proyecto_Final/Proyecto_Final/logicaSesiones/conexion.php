<?php


const SERVER ="localhost";
const BD ="lcbox";
const USER ="root";
const PASS ="";


const SGBD="mysql:host=".SERVER.";dbname=".BD;

class dbconexion{
     public function conexion(){
        $con = new PDO(SGBD,USER,PASS);
        return $con;
     }
}

?>