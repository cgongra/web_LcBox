let sesion;
window.onload = function() {}
var btnLog = document.getElementById("btnLog");


function mostrarGif(x) {
    x.setAttribute("src", "images/logoGif.gif");
}

function ocultarGif(x) {
    x.setAttribute("src", "images/logoIndex.png");
}

/**No hace nada realmente no se porque */
var mensajes = document.getElementById("respuesta");

function validarLogin() {

    let form = document.getElementById("formularioLogin");
    e.preventDefault();
    //  alert("se dio clik");
    let datos = new FormData(form);
    let usuario = datos.get('usuario');
    let pasword = datos.get('pasword');
    let tipo_mensaje = "";
    mensajes.innerHTML = "";
    if (usuario == "") {
        tipo_mensaje = "Debes introducir un usuario";
        mensajeValidacion(tipo_mensaje);
        return false;
    } else if (pasword == "") {
        tipo_mensaje = "Debes introducir una contraseña";
        mensajeValidacion(tipo_mensaje);
        return false;
    }

    fetch("logicaSesiones/logear.php", {
            method: 'post',
            body: datos
        })
        .then(data => data.json())
        .then(data => {
            console.log('success', data);
            switch (data) {
                case "error":
                    tipo_mensaje = "La clave y el usuario no coinciden";
                    mensajeValidacion(tipo_mensaje);
                    break;
                case "admin":
                    logAdmin();
                    break;

                case "user":
                    logUser();
                    break;

                default:
                    respuesta.innerHTML = `<b>${data}</b>`;
                    break;
            }

        })
        .catch(function(error) {
            console.log('error', error);
        });

}


function mensajeValidacion(tipo_mensaje) {
    mensajes.innerHTML += `
  <div class="row">
      <div class="col-md-5 offset-md-3">
          <div role="alert" class="alert alert-danger alert-dismissible">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
              <h4 class="alert-heading">Error!</h4>
              <p> *${tipo_mensaje}</p>
           </div>
      </div>
  </div>
   `;
}


function logAdmin() {
    document.getElementById("btnEdicionP").setAttribute("hidden", "false");
}

function logUser() {
    document.getElementById("btnEdicionP").setAttribute("hidden", "true");
}