<!DOCTYPE html>
<html lang="es">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="description" content="cajas sorpresa, box, papaleria, retuladores, lapices, gomas, estuches, bonitos">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="images/icon.jpg">
    <script src="logicaJS.js"></script>
    <title>LCBox Envios</title>

    <!-- Hoja de estilo css principal -->
    <link rel="stylesheet" href="css/style.css">
    <!--Links de Boostrap-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body class="fondo">
      <!--Cabecera-->
      <div class="sticky-top">
        <header>
            <nav class="navbar navbar-expand-xl bg-dark navbar-dark">
                <div class="navbar-brand">
                    <a href="index.php">
                        <img id="gif" class="static" src="images/logoIndex.png" onmouseover="mostrarGif(this)" onmouseout="ocultarGif(this)">
                    </a>
                </div>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                        <span class="navbar-toggler-icon"></span>
                        </button>
                <div class="collapse navbar-collapse " id="collapsibleNavbar">

                    <ul class="nav navbar-nav">

                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Inicio</a>
                        </li>
                       
                        <li class="nav-item">
                            <a class="nav-link" href="productos.php">Productos</a>
                        </li>
                       <?php 
                       session_start();
                       
                       if (isset($_SESSION['username'])) {
                            if($_SESSION['username']=="admin"){
                                echo '
                            <li class="nav-item" id="btnEdicionP">
                            <a class="nav-link" href="tablaP.php">Edición de Productos</a>
                            </li>
                                 ';
                            }     
                         }
                       ?>
                        <li class="nav-item">
                            <a class="nav-link" href="envios.php">Envíos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contacto.php">Contacto</a>
                        </li>
                    </ul>

                    <ul  id = "btnLog" class="col-5 btn-group btn-group-justified d-inline-flex nav navbar-nav navbar-nav-rigth">
                        <?php
                       
                       
                       if (isset($_SESSION['username'])) {
                        $user = $_SESSION['username'];
                        echo '
                        <li class="col-sm-6 d-xs-inline nav-item">
                            <a class="btn btn-outline-danger navbar-btn nav-link" href="logicaSesiones/salir.php"><span class="fa fa-user-plus "aria-hidden="true" ></span> Cerrar Sesión</a>
                        </li>

                        <li class="col-sm-6  nav-item">
                            <a class="btn btn-outline-danger navbar-btn nav-link" href="#"><span class="fa fa-sign-in" aria-hidden="true"></span> Hola '.$user.'!</a>
                        </li>';
                        }else{
                        echo '
                            <li class="col-sm-6 d-xs-inline nav-item">
                                 <a class="btn btn-outline-danger navbar-btn nav-link" href="registro.php"><span class="fa fa-user-plus "aria-hidden="true" ></span> Registrarse</a>
                             </li>

                             <li class="col-sm-6  nav-item">
                                 <a class="btn btn-outline-danger navbar-btn nav-link" href="login.php"><span class="fa fa-sign-in" aria-hidden="true"></span> Iniciar Sesión</a>
                             </li>';
                      }
                       
                       ?>
                    
                       
                    </ul>

                </div>
            </nav>

        </header>
    </div>
    <!--Cuerpo-   CRUD en tabla de productos-->
    
    <div class="container"><br>
        <form action="" id="form" method="POST">
            <div class="row">
                <input type="text" name="tipOpe" value="guardar" hidden="true">
                <div class="col-md-4">
                    <input type="text" id="imagen" name="imagen" class="form-control" placeholder="Imagen" autocomplete="off">
                </div>
                <div class="col-md4">
                    <input type="text" id="nombre" name="nombre" class="form-control" placeholder="Nombre" autocomplete="off">
                </div>
                <div class="col-md-2">
                    <input type="number" id="precio" name="precio" class="form-control" placeholder="Precio" autocomplete="off">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-block btn-info">Aceptar</button>
                </div>
            </div>

        </form>
    </div>
    <br>
    <div class="container" id="mensajes"></div>
    <br>
    <div class="container"><br>
        <table class="table table bordered border-dark">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Precio</th>
                    <th>Imagen</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody id="tablaProducto">
                <?php 
                    require_once "logicaSesiones/conexion.php";
                    require_once "logicaSesiones/ConsultasContoller.php";

                    $sentencia = new consultas();
                    $mostrarDatos= $sentencia->selectProducto();
                    
                    foreach($mostrarDatos as $res){
                        $id = $res["idProducto"];
                        echo "<tr>";
                        echo "<td>".$id."</td>";
                        echo "<td>".$res["nombre"]."</td>";
                        echo "<td>".$res["precio"]."</td>";
                        echo "<td> <img class='img-thumbnail ml-3 w-20 h-auto' src=".$res["imagen"]." alt='640283666'></td>";
                        echo "<td class='text-center'>
                        <button class='btn btn-primary btn-sm' onclick='editar($id);'>Editar</button>
                        <button class='btn btn-danger btn-sm' onclick='eliminar($id);'>Eliminar</button>
                        </td>";
                        echo "</tr>";
                    }


                ?>
            </tbody>
        </table>

    </div>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="JavaScript/funciones.js"></script>



</body>



</body>

</html>