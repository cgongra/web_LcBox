<?php 
                 /**
                      require_once '../logicaSesiones/conexion.php';
                     require_once '../logicaSesiones/ConsultasContoller.php';
                   // $nombre,$apellidos,$email, $telefono, $direccion, $usuario, $clave
            if(isset($_POST['nombre'])){                   
                    $nombre = $_POST['nombre'];
                    $apellidos = $_POST['apellidos'];
                    $email = $_POST['email'];
                    $telefono = $_POST['telefono'];
                    $direccion = $_POST['direccion'];
                    $usuario = $_POST['usuario'];
                    $clave = $_POST['clave'];
                    $sentencia = new consultas();
                if(isset($_POST['telefono'])){
                    $resultado= $sentencia->insertarUsuario($nombre,$apellidos,$email, $telefono, $direccion, $usuario, $clave);

                    switch($resultado){
                        case "repetido":
                            echo '
                            <div class="row mt-2">
                            <div class="col-md-8 offset-md-2">
                                <div role="alert" class="alert alert-danger alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                                    <h4 class="alert-heading">El usuario ya se encuentra en nuestra base de datos</h4>
                                 </div>
                            </div>
                        </div>
                            ';
                        break;

                        case "success":
                            echo '
                            <div class="row mt-2">
                            <div class="col-md-5 offset-md-3">
                                <div role="alert" class="alert alert-success alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                                    <h4 class="alert-heading">¡Registrado correctamente!</h4>
                                 </div>
                            </div>
                        </div>
                            ';
                        break;
                        
                        case "error":
                            echo '
                            <div class="row mt-2">
                            <div class="col-md-5 offset-md-3">
                                <div role="alert" class="alert alert-danger alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                                    <h4 class="alert-heading">¡Error! No se ha podido registrar el usuario</h4>
                                 </div>
                            </div>
                        </div>
                            ';

                        break;

                    }
                }
            }*/ 
            ?>