<?php
    require_once '../logicaSesiones/conexion.php';
    require_once '../logicaSesiones/ConsultasContoller.php';
    $tipo_consulta = $_POST['tipOpe'];

    switch($tipo_consulta){
        case 'guardar':
            $nombre = $_POST['nombre'];
            $precio= $_POST['precio'];
            $img= $_POST['imagen'];
            $consultas = new consultas();
            $ejecutar = $consultas -> insertarProducto($nombre,$precio,$img);
            echo json_encode($ejecutar);
            
            break;
        case 'editar':
                $id = $_POST['id'];
                $consultas = new consultas();
                $ejecutar = $consultas -> obtenerProducto($id);
                echo json_encode($ejecutar);
            break;
        case 'actualizar':
            $id = $_POST["uid"];
            $nombre = $_POST["unombre"];
            $precio = $_POST["uprecio"];
            $imagen = $_POST["uimagen"];
            $consultas= new consultas();
            $ejecutar = $consultas -> actualizar_producto($id, $nombre, $precio, $imagen) ;
            echo json_encode($ejecutar);

            break;
        case 'eliminar':
            $id = $_POST["id"];
            $consultas = new consultas();
            $ejecutar = $consultas -> eliminar_producto($id);
            echo json_encode($ejecutar);
            break;
        case 'cookies':
            $id = $_POST["id"];
            setcookie("id", $id, time() + (86400 * 30), "/"); 
            $consultas = new consultas();
            $ejecutar = $consultas -> obtenerProducto($id);
            echo json_encode($ejecutar);
            break;
        default:

            break;
    }

?>