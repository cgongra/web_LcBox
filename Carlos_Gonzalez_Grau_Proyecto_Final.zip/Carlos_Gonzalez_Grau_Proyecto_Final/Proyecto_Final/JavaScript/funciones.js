console.log("Se conecto");

const url = "./logicaPHP/ejecutarConsultas.php";
var mensajes = document.getElementById("mensajes");
let form = document.getElementById('form');
form.addEventListener('submit', (e) => {
    e.preventDefault();
    //  alert("se dio clik");
    let datos = new FormData(form);
    let nombre = datos.get('nombre');
    let precio = datos.get('precio');
    let tipo_mensaje = "";
    mensajes.innerHTML = "";
    if (nombre == "") {
        tipo_mensaje = "Debes introducir un nombre";
        mensajeValidacion(tipo_mensaje);
        return false;
    } else if (precio == "") {
        tipo_mensaje = "Debes introducir un precio";
        mensajeValidacion(tipo_mensaje);
        return false;
    }


    fetch(url, {
            method: 'post',
            body: datos
        })
        .then(data => data.json())
        .then(data => {
            console.log('success', data);
            PINTAR_TABLA(data);
            form.reset();
        })
        .catch(function(error) {
            console.log('error', error);
        });
});

function mensajeValidacion(tipo_mensaje) {
    mensajes.innerHTML += `
    <div class="row">
        <div class="col-md-5 offset-md-3">
            <div role="alert" class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
                <h4 class="alert-heading">Error!</h4>
                <p> *${tipo_mensaje}</p>
             </div>
        </div>
    </div>
     `;
}
const PINTAR_TABLA = (data) => {
    let tablaDatos = document.getElementById("tablaProducto");
    //vaciamos lo que haya en la tabla para repintarla 
    tablaDatos.innerHTML = "";
    //Repintamos la tabla. con los datos recibidos por data
    for (let item of data) {
        tablaDatos.innerHTML += `
        <tr>
        <td>${item.idProducto}</td>
        <td>${item.nombre}</td>
        <td>${item.precio}</td>
        <td> 
        <img class='img-thumbnail ml-3 w-20 h-auto'  src="${item.imagen}" alt='640283666'>
        </td>

        <td class='text-center'>
            <button class='btn btn-primary btn-sm' onclick='editar(${item.idProducto})'>Editar</button>
            <button class='btn btn-danger btn-sm' onclick='eliminar(${item.idProducto});'>Eliminar</button>
        </td>
        </tr>
        `;
    }
}

function setCookies(id) {
    // alert(id);
    let formData = new FormData();
    formData.append('tipOpe', 'cookies');
    formData.append('id', id);
    fetch(url, {
            method: 'POST',
            body: formData

        })
        .then(data => data.json())
        .then(data => {
            console.log('success', data);
            Swal.fire({
                icon: 'success',
                title: 'Añadido al Carrito correctamente.',
                width: 600,
                padding: '3em',
                color: '#716add',
                background: '#fff',
                backdrop: `
                  rgba(0,0,123,0.4)
                  url("images/logoGif.gif")
                  center top
                  no-repeat
                `
            })
        })
        .catch(error => console.error('Error:', error));


}

function eliminar(id) {
    // alert(id);
    Swal.fire({
        title: '¿Estas seguro?',
        text: "Una vez eliminado no se podrá recuperar el registro!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Aceptar'
    }).then((result) => {
        if (result.isConfirmed) {
            let formData = new FormData();
            formData.append('tipOpe', 'eliminar');
            formData.append('id', id);
            fetch(url, {
                    method: 'POST',
                    body: formData

                })
                .then(data => data.json())
                .then(data => {
                    console.log('success', data);
                    PINTAR_TABLA(data);
                    Swal.fire(
                        'Eliminado',
                        'El registro se eliminó correctamente.',
                        'success'
                    )
                })
                .catch(error => console.error('Error:', error));


        }
    })
}

function editar(idProducto) {
    //alert(idProducto);
    let formData = new FormData();

    formData.append('tipOpe', 'editar');
    formData.append('id', idProducto);

    fetch(url, {
            method: 'POST',
            body: formData

        })
        .then(data => data.json())
        .then(data => {
            console.log('success', data);
            for (let item of data) {
                //con var podemos acceder a la variable fuera del for
                var idProd = idProducto;
                var nombre = item.nombre;
                var precio = item.precio;
                var imagen = item.imagen;
            }

            //Importacion de la ventana modal de sweetalert2      
            Swal.fire({
                title: 'Editar Producto',
                html: `
                <form id = "update">
                    <input type="text" name="tipOpe" value="actualizar" hidden="true">
                    <input type="text" value="${idProd}" name ="uid" class="form-control" hidden="true" >
                    <input type="text" value="${nombre}" name ="unombre" class="form-control" placeholder="Nombre">
                    <hr>
                    <input type="number" value="${precio}" name ="uprecio" class="form-control" placeholder="Precio">
                    <hr>
                    <input type="text" name ="uimagen" class="form-control" placeholder="URL de la imagen" id="imagenCambio" value="${imagen}" onchange="refrescaImagen()">
                    <hr> 
                    <img class='img-fluid img-thumbnail ml-3 w-20 h-auto' id="imgMuestra" src="${imagen}" alt='Imagen no disponible'>              
                </form>`,
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Listo!'

            }).then((result) => {
                if (result.isConfirmed) {
                    //Aqui obtengo los datos del formulario, lo meto en una constante
                    const datos = document.getElementById("update");
                    const datos_actualizar = new FormData(datos);
                    //Estructura fetch para enviar los datos obtenidos
                    fetch(url, {
                            method: "post",
                            body: datos_actualizar
                        })
                        .then(data => data.json())
                        .then(data => {
                            console.log("success", data);
                            PINTAR_TABLA(data);
                            Swal.fire(
                                'Editado Correctamente!',
                                'El producto ha sido modificado correctamente',
                                'success'
                            )
                        })
                        .catch(function(error) {
                            console.log("error", error);
                        });


                }
            })
        })
        .catch(function(error) {
            console.error('error', error)

        });


}
//Funcion para el alert de edicion de la tabla de productos
function refrescaImagen() {
    let origen = document.getElementById("imagenCambio").value;
    let destino = document.getElementById("imgMuestra");
    destino.setAttribute("src", origen);
    origen = destino.value;
}